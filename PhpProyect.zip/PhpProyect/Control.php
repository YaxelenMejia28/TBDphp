<?php
    include ("conexion.php");
    $query= "SELECT * FROM libros";
    $result1= $connection->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="CssPortadas.css">
</head>
<body>
    <form method="post" class="form2">
    <div class= "Izquierda">
        <br>
        <h3>TECNM</h3>
        <h3>CHETUMAL</h3>
        <br>
        <br>
       <input type="button" onclick="window.location.href='Principal.php';" value="Principal" />
       <input type="button" onclick="window.location.href='Prestamo.php';" value="Prestamos" /><input type="button" onclick="window.location.href='Devoluciones.php';" value="Devoluciones" /><input type="button" onclick="window.location.href='EditarUsuario.php';" value="Usuarios" /><input type="button" onclick="window.location.href='EditarLibro.php';" value="Libros" />
       <input type="button" onclick="window.location.href='Principal.php';" value="Reportes" />
    </div>

    <h6>Biblioteca virtual del Instituto Tecnologico de chetumal</h6>
    <br>
    <div class="Derecha">
        <h4>Administración/Control/Biblioteca<h4>
            <h4>Bienvenido<h4>
                <br>
                <h4>Sistema de Gestion para la biblioteca Virtual del ITCH. Controle y administre de forma ólptima y facil el flujo de prestamos y devoluciones de Libros.</h4>
                <br>
                <h4>Esta herramienta le permitira llevar un control completo y detalldo de su biblioteca, tendrá acceso a herramientas especiales para tareas como: </h4>
                <br>
                <h4> *Préstamos</h4>
                <h4>*Devoluciones</h4>
                <h4>*Registro de Usuario y Libros Nuevos</h4>
                <h4>*Edicion de Usuarios y Libros existentes</h4>
                <h4>*Eliminiar todo de registros</h4>
                <h4>*Sección de reportes de acciones en el sistema</h4>
            </div>
        </form>
    </body>
</html>