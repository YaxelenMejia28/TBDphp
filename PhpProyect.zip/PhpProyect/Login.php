<?php
    include ("conexion.php");
    $query= "SELECT * FROM usuario";
    $result1= $connection->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Css.css">
</head>
    </header>
    <form method="post">
        <center><h1><b>Inicio de sesion</b></h1></center>
    
    <h3>Sesion para el bibliotecario:</h3><input type="text" name="">
      <label for="contrasena">Contraseña:</label><input type="text" name="">

    <h3>Sesion para el Administrador:</h3><input type="text" name="">
      <label for="contrasena">Contraseña:</label><input type="text" name="">
    
    <input type="submit" value="Iniciar sesión">
    </form>
</body>
</html>