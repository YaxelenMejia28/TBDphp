<?php
//datos y la conexion con la base de datos
$dbhost = 'localhost';
$dbname = 'biblioteca_itch';
$dbuser = 'root';
$dbpass = '';

$connection = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if ($connection->connect_error) die("fatal Error"); 
?>