<?php
    include ("conexion.php");
    $query= "SELECT * FROM libros";
    $result1= $connection->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="CssPortadas.css">
</head>
<body>
    <form method="post" class="form2">
        <div class= "Izquierda">
            <br>
            <h3>TECNM</h3>
            <h3>CHETUMAL</h3>
            <br>
            <br>
            <input type="button" onclick="window.location.href='Principal.php';" value="Principal" />
            <input type="button" onclick="window.location.href='Prestamo.php';" value="Prestamos" /><input type="button" onclick="window.location.href='Devoluciones.php';" value="Devoluciones" /><input type="button" onclick="window.location.href='EditarUsuario.php';" value="Usuarios" /><input type="button" onclick="window.location.href='EditarLibro.php';" value="Libros" />
            <input type="button" onclick="window.location.href='Principal.php';" value="Reportes" />
        </div>
         <h6>Biblioteca virtual del Instituto Tecnologico de chetumal</h6>
         <br>
         <div class="Derecha">
            <h4>Administración/Control/Biblioteca<h4>
                <h4>Libros<h4>
                    <?php
                    if ($result1->num_rows > 0) {
                        // Generar la tabla con los resultados de la consulta
                        echo '<table>';
                        echo '<tr>';
                        echo '<th>ISBN</th>';
                        echo '<th>Titulo</th>';
                        echo '<th>Autor</th>';
                        echo '<th>Genero</th>';
                        echo '</tr>';
                        while ($row = $result1->fetch_assoc()) {
                            echo '<tr class= tr1>';
                            echo '<td>' . $row['ISBN'] . '</td>';
                            echo '<td>' . $row['Titulo'] . '</td>';
                            echo '<td>' . $row['Autor'] . '</td>';
                            echo '<td>' . $row['Genero'] . '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo 'No se encontraron resultados.';
                    }
                
                    $connection->close();
                    ?>
            <input type="submit" name="" value="Nuevo">
        </div>
    </form>
</body>
</html>